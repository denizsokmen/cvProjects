Compiled and tested under Fedora 20

The program uses UNIX Dirent API library for file traversal. Also ported to Visual Studio : http://softagalleria.net/dirent.php

Requires DATASET folder in the working directory to function properly.
